function MainFeed({postClicked}){
    return(
        <div>Main Feed</div>
    );
}
export default MainFeed;